package com.java1234.service.impl;

import com.java1234.entity.Course;
import com.java1234.mapper.CourseMapper;
import com.java1234.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 课程Service实现类
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:34
 */
@Service("courseService")
public class CourseServiceImpl implements CourseService {

    @Autowired
    private CourseMapper courseMapper;

    @Override
    public List<Course> search(Map<String,Object> map) {
        return courseMapper.search(map);
    }

    @Override
    public Long getTotal(Map<String, Object> map) {
        return courseMapper.getTotal(map);
    }

    @Override
    public Course findById(Integer id) {
        return courseMapper.findById(id);
    }

    @Override
    public List<Course> listHktj() {
        return courseMapper.listHktj();
    }

    @Override
    public List<Course> listAllHktj() {
        return courseMapper.listAllHktj();
    }

    @Override
    public List<Course> listZxkc() {
        return courseMapper.listZxkc();
    }

    @Override
    public List<Course> listAllZxkc() {
        return courseMapper.listAllZxkc();
    }

    @Override
    public List<Course> listMfkc() {
        return courseMapper.listMfkc();
    }

    @Override
    public List<Course> listAllMfkc() {
        return courseMapper.listAllMfkc();
    }

    @Override
    public List<Course> listSzkc() {
        return courseMapper.listSzkc();
    }

    @Override
    public List<Course> listAllSzkc() {
        return courseMapper.listAllSzkc();
    }

    @Override
    public List<Course> listRecommend() {
        return courseMapper.listRecommend();
    }

    @Override
    public Integer add(Course course) {
        return courseMapper.add(course);
    }

    @Override
    public Integer update(Course course) {
        return courseMapper.update(course);
    }

    @Override
    public Integer updateHktj(Course course) {
        return courseMapper.updateHktj(course);
    }

    @Override
    public Integer updateZxkc(Course course) {
        return courseMapper.updateZxkc(course);
    }

    @Override
    public Integer updateMfkc(Course course) {
        return courseMapper.updateMfkc(course);
    }

    @Override
    public Integer updateSzkc(Course course) {
        return courseMapper.updateSzkc(course);
    }

    @Override
    public Integer delete(Integer id) {
        return courseMapper.delete(id);
    }
}
