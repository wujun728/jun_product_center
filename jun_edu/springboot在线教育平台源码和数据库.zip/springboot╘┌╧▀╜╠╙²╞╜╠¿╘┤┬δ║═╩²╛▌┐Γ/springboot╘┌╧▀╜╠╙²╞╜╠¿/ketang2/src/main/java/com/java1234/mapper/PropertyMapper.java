package com.java1234.mapper;

import com.java1234.entity.Property;

import java.util.List;

/**
 * 系统属性Mapper接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:41
 */
public interface PropertyMapper {

    /**
     * 查询所有属性
     * @return
     */
    public List<Property> list();

    /**
     * 更新
     * @param property
     * @return
     */
    public Integer update(Property property);

    /**
     * 根据id查询实体
     * @param id
     * @return
     */
    public Property findById(Integer id);



}
