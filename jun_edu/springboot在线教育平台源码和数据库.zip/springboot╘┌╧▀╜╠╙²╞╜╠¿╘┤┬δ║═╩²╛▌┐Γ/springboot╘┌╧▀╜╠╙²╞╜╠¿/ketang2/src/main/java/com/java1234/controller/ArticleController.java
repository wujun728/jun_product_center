package com.java1234.controller;

import com.java1234.entity.Article;
import com.java1234.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * 帖子控制器
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-03-21 17:34
 */
@Controller
@RequestMapping("/article")
public class ArticleController {

    @Autowired
    private ArticleService articleService;

    /**
     * 根据id查询帖子详细信息
     * @param id
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/{id}")
    public ModelAndView view(@PathVariable("id")Integer id)throws Exception{
        ModelAndView mav=new ModelAndView();
        Article article = articleService.findById(id);
        mav.setViewName("article");
        mav.addObject("article",article);
        mav.addObject("modelName",article.getTitle());
        mav.addObject("title",article.getTitle());
        return mav;
    }


}
