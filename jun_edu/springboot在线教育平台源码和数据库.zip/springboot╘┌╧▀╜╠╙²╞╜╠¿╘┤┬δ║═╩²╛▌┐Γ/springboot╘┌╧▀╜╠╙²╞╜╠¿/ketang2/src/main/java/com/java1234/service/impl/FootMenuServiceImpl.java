package com.java1234.service.impl;

import com.java1234.entity.FootMenu;
import com.java1234.mapper.FootMenuMapper;
import com.java1234.service.FootMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-04-10 9:50
 */
@Service("footMenuService")
public class FootMenuServiceImpl implements FootMenuService {

    @Autowired
    private FootMenuMapper footMenuMapper;

    @Override
    public List<FootMenu> list() {
        return footMenuMapper.list();
    }

    @Override
    public Long getTotal() {
        return footMenuMapper.getTotal();
    }

    @Override
    public FootMenu findById(Integer id) {
        return footMenuMapper.findById(id);
    }

    @Override
    public Integer add(FootMenu footmenu) {
        return footMenuMapper.add(footmenu);
    }

    @Override
    public Integer update(FootMenu footmenu) {
        return footMenuMapper.update(footmenu);
    }

    @Override
    public Integer delete(Integer id) {
        return footMenuMapper.delete(id);
    }
}
