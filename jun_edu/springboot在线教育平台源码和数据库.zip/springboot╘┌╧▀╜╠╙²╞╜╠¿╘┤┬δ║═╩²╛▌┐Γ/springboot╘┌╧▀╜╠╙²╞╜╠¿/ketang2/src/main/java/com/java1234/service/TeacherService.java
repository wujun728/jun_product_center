package com.java1234.service;

import com.java1234.entity.Teacher;

import java.util.List;

/**
 * 授课老师Service接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:33
 */
public interface TeacherService {

    /**
     * 查询所有授课老师
     * @return
     */
    public List<Teacher> list();

    /**
     * 根据id查询实体
     * @param id
     * @return
     */
    public Teacher findById(Integer id);

    /**
     * 添加授课老师
     * @param teacher
     * @return
     */
    public Integer add(Teacher teacher);

    /**
     * 修改授课老师
     * @param teacher
     * @return
     */
    public Integer update(Teacher teacher);

    /**
     * 删除授课老师
     * @param id
     * @return
     */
    public Integer delete(Integer id);
}
