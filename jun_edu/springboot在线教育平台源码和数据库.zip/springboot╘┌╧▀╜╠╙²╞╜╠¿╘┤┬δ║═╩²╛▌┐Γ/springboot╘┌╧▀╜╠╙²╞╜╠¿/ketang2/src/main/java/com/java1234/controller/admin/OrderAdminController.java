package com.java1234.controller.admin;

import com.java1234.entity.Order;
import com.java1234.entity.PageBean;
import com.java1234.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员-订单控制器
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value = "/admin/order")
public class OrderAdminController {

	@Autowired
	private OrderService orderService;



	/**
	 * 根据条件分页查询订单
	 * @param page
	 * @param limit
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value = "/list")
	public Map<String,Object> list(@RequestParam(value="page",required=false)Integer page,@RequestParam(value="limit",required=false)Integer limit,@RequestParam(value="orderNo",required=false)String orderNo,@RequestParam(value="openid",required=false)String openid)throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		PageBean pageBean=new PageBean(page,limit);
		Map<String,Object> map=new HashMap<>();
		map.put("orderNo",orderNo);
		map.put("openid",openid);
		map.put("start",pageBean.getStart());
		map.put("size",pageBean.getPageSize());
		List<Order> orderList=orderService.list(map);
		Long count=orderService.getTotal(map);
		resultMap.put("code", 0);
		resultMap.put("count", count);
		resultMap.put("data", orderList);
		return resultMap;
	}
	

}
