package com.java1234.service;

import com.java1234.entity.CarouselArticle;

import java.util.List;

/**
 * 轮播帖子Service接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:33
 */
public interface CarouselArticleService {

    /**
     * 查询所有轮播帖子
     * @return
     */
    public List<CarouselArticle> list();

    /**
     * 根据id查询实体
     * @param id
     * @return
     */
    public CarouselArticle findById(Integer id);

    /**
     * 添加轮播帖子
     * @param carouselArticle
     * @return
     */
    public Integer add(CarouselArticle carouselArticle);

    /**
     * 修改轮播帖子
     * @param carouselArticle
     * @return
     */
    public Integer update(CarouselArticle carouselArticle);

    /**
     * 删除轮播帖子
     * @param id
     * @return
     */
    public Integer delete(Integer id);
}
