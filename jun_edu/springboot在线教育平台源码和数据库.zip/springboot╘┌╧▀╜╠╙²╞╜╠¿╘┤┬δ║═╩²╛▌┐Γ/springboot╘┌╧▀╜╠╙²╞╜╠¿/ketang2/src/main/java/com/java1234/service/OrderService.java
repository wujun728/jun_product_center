package com.java1234.service;

import com.java1234.entity.Order;

import java.util.List;
import java.util.Map;

/**
 * 订单Service接口实现类
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-06-05 21:41
 */
public interface OrderService {

    /**
     * 根据条件分页查询订单
     * @return
     */
    public List<Order> list(Map<String, Object> map);

    /**
     * 根据条件查询订单总记录数
     * @param map
     * @return
     */
    public Long getTotal(Map<String, Object> map);

    /**
     * 根据id查询订单
     * @param id
     * @return
     */
    public Order findById(String id);


    /**
     * 添加订单
     * @param order
     * @return
     */
    public Integer add(Order order);

    /**
     * 修改订单
     * @param order
     * @return
     */
    public Integer update(Order order);


    /**
     * 删除订单
     * @param id
     * @return
     */
    public Integer delete(Integer id);
}
