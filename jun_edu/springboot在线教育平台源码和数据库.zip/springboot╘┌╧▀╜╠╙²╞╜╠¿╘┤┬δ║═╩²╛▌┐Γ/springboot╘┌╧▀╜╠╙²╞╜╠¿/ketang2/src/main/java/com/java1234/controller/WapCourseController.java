package com.java1234.controller;

import com.java1234.entity.Course;
import com.java1234.entity.PageBean;
import com.java1234.service.CourseService;
import com.java1234.util.PageUtil;
import com.java1234.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 课程控制器-移动端
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-06 下午 10:26
 */
@Controller
@RequestMapping("/wap/course")
public class WapCourseController {

    @Autowired
    private CourseService courseService;



    /**
     * 根据id查询帖子详细信息
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping("/{id}")
    public ModelAndView view(@PathVariable("id")Integer id)throws Exception{
        ModelAndView mav=new ModelAndView();
        Course course = courseService.findById(id);
        mav.setViewName("wapCourse");
        mav.addObject("course",course);
        mav.addObject("recommendList",courseService.listRecommend());
        mav.addObject("modelName",course.getName());
        mav.addObject("title",course.getName());
        return mav;
    }

    /**
     * 异步更新view加1操作
     * @param id
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/updateView")
    public void updateView(Integer id)throws Exception{
        Course course = courseService.findById(id);
        course.setView(course.getView()+1);
        courseService.update(course);
    }


    /**
     * 跳到课程列表页面
     * @return
     * @throws Exception
     */
    @RequestMapping("/list")
    public ModelAndView toCourseList(HttpServletResponse response)throws Exception{
        ModelAndView mav=new ModelAndView();
        mav.addObject("title","课程列表");
        mav.setViewName("wapCourseList");
        return mav;
    }

    /**
     * 根据条件异步加载课程信息
     * @param page
     * @param s_typeId 课程类型
     * @param s_type 课程类别
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/loadCourseList")
    public Map<String,Object> loadCourseList(Integer page,@RequestParam(value="s_typeId",required=false)Integer s_typeId, @RequestParam(value="s_type",required=false)String s_type)throws Exception{

        PageBean pageBean=new PageBean(page,10);
        Map<String,Object> map=new HashMap<>();
        map.put("typeId",s_typeId);
        map.put("type",s_type);
        map.put("start", pageBean.getStart());
        map.put("size", pageBean.getPageSize());
        List<Course> courseList = courseService.search(map);

        Map<String,Object> resultMap=new HashMap<>();
        resultMap.put("courseList",courseList);
        resultMap.put("success",true);
        return resultMap;
    }

    /**
     * 根据条件搜索课程
     * @param s_name 搜索条件 课程名称
     * @return
     * @throws Exception
     */
    @RequestMapping("/search")
    public ModelAndView search(String s_name)throws Exception{
        PageBean pageBean=new PageBean(1,10);
        Map<String,Object> map=new HashMap<>();
        if(StringUtil.isNotEmpty(s_name)){
            map.put("name",s_name.trim());
        }
        map.put("start", pageBean.getStart());
        map.put("size", pageBean.getPageSize());
        List<Course> courseList = courseService.search(map);
        ModelAndView mav=new ModelAndView();
        mav.addObject("courseList",courseList);
        mav.addObject("s_name",s_name);
        mav.addObject("title",s_name);
        mav.setViewName("wapSearchResult");
        return mav;

    }

}
