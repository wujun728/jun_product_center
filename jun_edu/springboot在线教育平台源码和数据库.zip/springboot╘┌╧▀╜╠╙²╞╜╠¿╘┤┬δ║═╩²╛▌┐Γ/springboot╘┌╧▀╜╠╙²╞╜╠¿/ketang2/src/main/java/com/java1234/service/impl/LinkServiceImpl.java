package com.java1234.service.impl;

import com.java1234.entity.Link;
import com.java1234.mapper.LinkMapper;
import com.java1234.service.LinkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 系统属性Service实现类
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-10 下午 12:25
 */
@Service("linkService")
public class LinkServiceImpl implements LinkService {

    @Autowired
    private LinkMapper linkMapper;

    @Override
    public List<Link> list(Map<String,Object> map) {
        return linkMapper.list(map);
    }

    @Override
    public Long getTotal(Map<String, Object> map) {
        return linkMapper.getTotal(map);
    }

    @Override
    public Link findById(Integer id) {
        return linkMapper.findById(id);
    }

    @Override
    public Integer add(Link link) {
        return linkMapper.add(link);
    }

    @Override
    public Integer update(Link link) {
        return linkMapper.update(link);
    }

    @Override
    public Integer delete(Integer id) {
        return linkMapper.delete(id);
    }
}
