package com.java1234.service.impl;

import com.java1234.entity.CourseType;
import com.java1234.mapper.CourseTypeMapper;
import com.java1234.service.CourseTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 系统属性Service实现类
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-10 下午 12:25
 */
@Service("courseTypeService")
public class CourseTypeServiceImpl implements CourseTypeService {

    @Autowired
    private CourseTypeMapper courseTypeMapper;

    @Override
    public List<CourseType> list() {
        return courseTypeMapper.list();
    }

    @Override
    public CourseType findById(Integer id) {
        return courseTypeMapper.findById(id);
    }

    @Override
    public Integer add(CourseType courseType) {
        return courseTypeMapper.add(courseType);
    }

    @Override
    public Integer update(CourseType courseType) {
        return courseTypeMapper.update(courseType);
    }

    @Override
    public Integer delete(Integer id) {
        return courseTypeMapper.delete(id);
    }
}
