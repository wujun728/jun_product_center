package com.java1234.controller.admin;

import com.java1234.entity.CourseType;
import com.java1234.run.StartupRunner;
import com.java1234.service.CourseTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员-课程类别控制器
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value = "/admin/courseType")
public class CourseTypeAdminController {

	@Autowired
	private CourseTypeService courseTypeService;

	@Autowired
	private StartupRunner startupRunner;
	


	/**
	 * 根据条件查询课程类别
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value = "/list")
	public Map<String,Object> list()throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		List<CourseType> courseTypeList=courseTypeService.list();

		resultMap.put("code", 0);

		resultMap.put("data", courseTypeList);
		return resultMap;
	}
	
	/**
	 * 添加或者修改课程类别
	 * @param courseType
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/save")
	public Map<String,Object> save(CourseType courseType){
		if(courseType.getId()==null){
			courseTypeService.add(courseType);
		}else{
			courseTypeService.update(courseType);
		}
		startupRunner.loadData();
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("success", true);
		return resultMap;
	}
	
	/**
	 * 删除课程类别
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/delete")
	public Map<String,Object> delete(Integer id)throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		courseTypeService.delete(id);
		startupRunner.loadData();
		resultMap.put("success", true);
		return resultMap;
	}
	
	/**
	 * 根据id查询课程类别实体
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/findById")
	public Map<String,Object> findById(Integer id)throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		CourseType courseType=courseTypeService.findById(id);
		resultMap.put("courseType", courseType);
		resultMap.put("success", true);
		return resultMap;
	}
}
