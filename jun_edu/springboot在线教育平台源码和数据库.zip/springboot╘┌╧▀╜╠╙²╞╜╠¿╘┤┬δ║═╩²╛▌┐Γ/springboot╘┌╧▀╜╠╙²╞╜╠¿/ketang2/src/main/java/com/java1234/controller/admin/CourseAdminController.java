package com.java1234.controller.admin;

import com.java1234.entity.Course;
import com.java1234.entity.Course;
import com.java1234.entity.PageBean;
import com.java1234.run.StartupRunner;
import com.java1234.service.CourseService;
import com.java1234.util.DateUtil;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员-课程控制器
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-03-19 20:03
 */
@Controller
@RequestMapping(value = "/admin/course")
public class CourseAdminController {

    @Autowired
    private CourseService courseService;

    @Autowired
    private StartupRunner startupRunner;

    @Value("${courseImagesFilePath}")
    private String courseImagesFilePath;

    /**
     * 根据条件分页查询课程
     * @param page
     * @param limit
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/list")
    public Map<String,Object> list(@RequestParam(value="page",required=false)Integer page, @RequestParam(value="limit",required=false)Integer limit, @RequestParam(value="name",required=false)String name)throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        PageBean pageBean=new PageBean(page,limit);
        Map<String,Object> map=new HashMap<>();
        map.put("name",name);
        map.put("start",pageBean.getStart());
        map.put("size",pageBean.getPageSize());
        List<Course> courseList=courseService.search(map);
        Long count=courseService.getTotal(map);
        resultMap.put("code", 0);
        resultMap.put("count", count);
        resultMap.put("data", courseList);
        return resultMap;
    }

    /**
     * 根据条件查询所有好课推荐
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/listAllHktj")
    public Map<String,Object> listAllHktj()throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        List<Course> courseList=courseService.listAllHktj();
        resultMap.put("code", 0);
        resultMap.put("data", courseList);
        return resultMap;
    }

    /**
     * 根据条件查询所有最新课程推荐
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/listAllZxkc")
    public Map<String,Object> listAllZxkc()throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        List<Course> courseList=courseService.listAllZxkc();
        resultMap.put("code", 0);
        resultMap.put("data", courseList);
        return resultMap;
    }

    /**
     * 根据条件查询所有免费课程推荐
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/listAllMfkc")
    public Map<String,Object> listAllMfkc()throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        List<Course> courseList=courseService.listAllMfkc();
        resultMap.put("code", 0);
        resultMap.put("data", courseList);
        return resultMap;
    }

    /**
     * 根据条件查询所有实战推荐
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/listAllSzkc")
    public Map<String,Object> listAllSzkc()throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        List<Course> courseList=courseService.listAllSzkc();
        resultMap.put("code", 0);
        resultMap.put("data", courseList);
        return resultMap;
    }



    /**
     * 添加免费课程
     * @param course
     * @return
     */
    @ResponseBody
    @RequestMapping("/addFree")
    public Map<String,Object> addFree(Course course){
        course.setImageName("default.jpg");
        course.setType("free");
        courseService.add(course);
        startupRunner.loadData();
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 添加Vip课程
     * @param course
     * @return
     */
    @ResponseBody
    @RequestMapping("/addVip")
    public Map<String,Object> addVip(Course course){
        course.setImageName("default.jpg");
        course.setType("vip");
        courseService.add(course);
        startupRunner.loadData();
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 添加或者修改课程
     * @param course
     * @return
     */
    @ResponseBody
    @RequestMapping("/save")
    public Map<String,Object> save(Course course){
        if(course.getId()==null){
            courseService.add(course);
        }else{
            courseService.update(course);
        }
        startupRunner.loadData();
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 更新好课推荐
     * @param course
     * @return
     */
    @ResponseBody
    @RequestMapping("/updateHktj")
    public Map<String,Object> updateHktj(Course course){
        courseService.updateHktj(course);
        startupRunner.loadData();
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 更新最新课程推荐
     * @param course
     * @return
     */
    @ResponseBody
    @RequestMapping("/updateZxkc")
    public Map<String,Object> updateZxkc(Course course){
        courseService.updateZxkc(course);
        startupRunner.loadData();
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 更新免费课程推荐
     * @param course
     * @return
     */
    @ResponseBody
    @RequestMapping("/updateMfkc")
    public Map<String,Object> updateMfkc(Course course){
        courseService.updateMfkc(course);
        startupRunner.loadData();
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 更新实战课程推荐
     * @param course
     * @return
     */
    @ResponseBody
    @RequestMapping("/updateSzkc")
    public Map<String,Object> updateSzkc(Course course){
        courseService.updateSzkc(course);
        startupRunner.loadData();
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 删除课程
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/delete")
    public Map<String,Object> delete(Integer id)throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        courseService.delete(id);
        startupRunner.loadData();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 根据id查询课程实体
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/findById")
    public Map<String,Object> findById(Integer id)throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        Course course=courseService.findById(id);
        resultMap.put("course", course);
        resultMap.put("success", true);
        return resultMap;
    }


    /**
     * 上传课程帖子图片
     * @param file
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/uploadImage")
    public Map<String,Object> uploadImage(MultipartFile file,Integer id)throws Exception{
        Map<String,Object> map=new HashMap<String,Object>();
        if(!file.isEmpty()){
            // 获取文件名
            String fileName = file.getOriginalFilename();
            // 获取文件的后缀名
            String suffixName = fileName.substring(fileName.lastIndexOf("."));
            String newFileName=DateUtil.getCurrentDateStr()+suffixName;



            FileUtils.copyInputStreamToFile(file.getInputStream(), new File(courseImagesFilePath+newFileName));
            map.put("code", 0);
            map.put("msg", "上传成功");
            Map<String,Object> map2=new HashMap<String,Object>();
            map2.put("title", newFileName);
            map2.put("src", "/courseImages/"+newFileName);
            map.put("data", map2);

            // 修改图片
            Course course = courseService.findById(id);
            course.setImageName(newFileName);
            courseService.update(course);

            startupRunner.loadData();

        }

        return map;
    }
    
}
