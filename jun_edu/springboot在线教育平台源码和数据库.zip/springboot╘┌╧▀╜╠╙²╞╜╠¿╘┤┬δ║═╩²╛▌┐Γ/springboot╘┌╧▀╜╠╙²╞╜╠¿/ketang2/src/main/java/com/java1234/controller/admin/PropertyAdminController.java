package com.java1234.controller.admin;

import com.java1234.entity.Property;
import com.java1234.run.StartupRunner;
import com.java1234.service.PropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员-系统属性控制器
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value = "/admin/property")
public class PropertyAdminController {

	@Autowired
	private PropertyService propertyService;

	@Autowired
	private StartupRunner startupRunner;
	


	/**
	 * 根据条件分页查询系统属性
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value = "/list")
	public Map<String,Object> list()throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		List<Property> propertyList=propertyService.list();
		resultMap.put("code", 0);
		resultMap.put("data", propertyList);
		return resultMap;
	}
	
	/**
	 *修改系统属性
	 * @param property
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/update")
	public Map<String,Object> update(Property property)throws Exception{
		propertyService.update(property);
		startupRunner.loadData();
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("success", true);
		return resultMap;
	}
	

	
	/**
	 * 根据id查询系统属性实体
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/findById")
	public Map<String,Object> findById(Integer id)throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		Property property=propertyService.findById(id);
		resultMap.put("property", property);
		resultMap.put("success", true);
		return resultMap;
	}
}
