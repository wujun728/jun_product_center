package com.java1234.service.impl;

import com.java1234.entity.CarouselArticle;
import com.java1234.mapper.CarouselArticleMapper;
import com.java1234.service.CarouselArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 轮播帖子Service实现类
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:34
 */
@Service("carouselArticleService")
public class CarouselArticleServiceImpl implements CarouselArticleService {

    @Autowired
    private CarouselArticleMapper carouselArticleMapper;

    @Override
    public List<CarouselArticle> list() {
        return carouselArticleMapper.list();
    }

    @Override
    public CarouselArticle findById(Integer id) {
        return carouselArticleMapper.findById(id);
    }

    @Override
    public Integer add(CarouselArticle carouselArticle) {
        return carouselArticleMapper.add(carouselArticle);
    }

    @Override
    public Integer update(CarouselArticle carouselArticle) {
        return carouselArticleMapper.update(carouselArticle);
    }

    @Override
    public Integer delete(Integer id) {
        return carouselArticleMapper.delete(id);
    }
}
