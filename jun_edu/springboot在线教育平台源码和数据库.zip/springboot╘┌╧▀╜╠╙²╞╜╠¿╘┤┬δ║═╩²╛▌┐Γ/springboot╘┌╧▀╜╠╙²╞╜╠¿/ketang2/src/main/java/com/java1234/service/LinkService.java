package com.java1234.service;

import com.java1234.entity.Link;

import java.util.List;
import java.util.Map;

/**
 * 友情链接Service接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:33
 */
public interface LinkService {

    /**
     * 查询友情链接
     * @return
     */
    public List<Link> list(Map<String,Object> map);

    /**
     * 获取总记录数
     * @param map
     * @return
     */
    public Long getTotal(Map<String,Object> map);

    /**
     * 根据id查询实体
     * @param id
     * @return
     */
    public Link findById(Integer id);

    /**
     * 添加友情链接信息
     * @param link
     * @return
     */
    public Integer add(Link link);

    /**
     * 修改友情链接信息
     * @param link
     * @return
     */
    public Integer update(Link link);

    /**
     * 删除友情链接信息
     * @param id
     * @return
     */
    public Integer delete(Integer id);


}
