package com.java1234.mapper;

import com.java1234.entity.Course;

import java.util.List;
import java.util.Map;

/**
 * 课程Mapper接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:41
 */
public interface CourseMapper {


    /**
     * 根据课程类别，课程分类和课程名称分页搜索课程
     * @return
     */
    public List<Course> search(Map<String,Object> map);

    /**
     * 根据条件，搜索课程总记录数
     * @param map
     * @return
     */
    public Long getTotal(Map<String,Object> map);

    /**
     * 根据id查询课程
     * @param id
     * @return
     */
    public Course findById(Integer id);

    /**
     * 查询前10条好课推荐课程
     * @return
     */
    public List<Course> listHktj();

    /**
     * 查询所有好课推荐课程
     * @return
     */
    public List<Course> listAllHktj();

    /**
     * 查询前10条最新课程
     * @return
     */
    public List<Course> listZxkc();

    /**
     * 查询所有最新课程
     * @return
     */
    public List<Course> listAllZxkc();

    /**
     * 查询前10条免费课程
     * @return
     */
    public List<Course> listMfkc();

    /**
     * 查询所有免费课程
     * @return
     */
    public List<Course> listAllMfkc();

    /**
     * 查询前10条实战课程
     * @return
     */
    public List<Course> listSzkc();

    /**
     * 查询所有实战课程
     * @return
     */
    public List<Course> listAllSzkc();

    /**
     * 随机查询10条推荐课程
     * @return
     */
    public List<Course> listRecommend();


    /**
     * 添加自定义课程信息
     * @param course
     * @return
     */
    public Integer add(Course course);

    /**
     * 修改自定义课程信息
     * @param course
     * @return
     */
    public Integer update(Course course);

    /**
     * 修改好课推荐设置
     * @param course
     * @return
     */
    public Integer updateHktj(Course course);

    /**
     * 修改最新课程推荐设置
     * @param course
     * @return
     */
    public Integer updateZxkc(Course course);

    /**
     * 修改免费课程推荐设置
     * @param course
     * @return
     */
    public Integer updateMfkc(Course course);

    /**
     * 修改收费课程推荐设置
     * @param course
     * @return
     */
    public Integer updateSzkc(Course course);



    /**
     * 删除自定义课程信息
     * @param id
     * @return
     */
    public Integer delete(Integer id);

}
