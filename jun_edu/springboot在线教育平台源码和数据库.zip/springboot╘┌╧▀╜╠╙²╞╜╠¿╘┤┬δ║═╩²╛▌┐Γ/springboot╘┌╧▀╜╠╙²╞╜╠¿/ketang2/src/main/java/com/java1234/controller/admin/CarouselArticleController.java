package com.java1234.controller.admin;

import com.java1234.entity.CarouselArticle;
import com.java1234.run.StartupRunner;
import com.java1234.service.CarouselArticleService;
import com.java1234.util.DateUtil;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员-轮播帖子控制器
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-04-20 21:58
 */
@Controller
@RequestMapping(value = "/admin/carouselArticle")
public class CarouselArticleController {

    @Autowired
    private CarouselArticleService carouselArticleService;

    @Autowired
    private StartupRunner startupRunner;

    @Value("${carouselImagesFilePath}")
    private String carouselImagesFilePath;

    /**
     * 根据条件分页查询轮播帖子
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/list")
    public Map<String,Object> list()throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        List<CarouselArticle> carouselArticleList=carouselArticleService.list();
        resultMap.put("code", 0);
        resultMap.put("data", carouselArticleList);
        return resultMap;
    }

    /**
     * 添加或者修改轮播帖子
     * @param carouselArticle
     * @return
     */
    @ResponseBody
    @RequestMapping("/save")
    public Map<String,Object> save(CarouselArticle carouselArticle){
        if(carouselArticle.getId()==null){
            carouselArticleService.add(carouselArticle);
        }else{
            carouselArticleService.update(carouselArticle);
        }
        startupRunner.loadData();
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 删除轮播帖子
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/delete")
    public Map<String,Object> delete(Integer id)throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        carouselArticleService.delete(id);
        startupRunner.loadData();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 根据id查询轮播帖子实体
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/findById")
    public Map<String,Object> findById(Integer id)throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        CarouselArticle carouselArticle=carouselArticleService.findById(id);
        resultMap.put("carouselArticle", carouselArticle);
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 上传轮播帖子图片
     * @param file
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/uploadImage")
    public Map<String,Object> uploadImage(MultipartFile file,Integer id)throws Exception{
        Map<String,Object> map=new HashMap<String,Object>();
        if(!file.isEmpty()){
            // 获取文件名
            String fileName = file.getOriginalFilename();
            // 获取文件的后缀名
            String suffixName = fileName.substring(fileName.lastIndexOf("."));
            String newFileName=DateUtil.getCurrentDateStr()+suffixName;



            FileUtils.copyInputStreamToFile(file.getInputStream(), new File(carouselImagesFilePath+newFileName));
            map.put("code", 0);
            map.put("msg", "上传成功");
            Map<String,Object> map2=new HashMap<String,Object>();
            map2.put("title", newFileName);
            map2.put("src", "/carouselImages/"+newFileName);
            map.put("data", map2);

            // 修改图片
            CarouselArticle carouselArticle = carouselArticleService.findById(id);
            carouselArticle.setImageName(newFileName);
            carouselArticleService.update(carouselArticle);

            startupRunner.loadData();

        }

        return map;
    }
    
    
}
