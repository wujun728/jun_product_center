package com.java1234.service;

import com.java1234.entity.FootMenu;

import java.util.List;

/**
 * 底部菜单Service接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-04-10 9:33
 */
public interface FootMenuService {

    /**
     * 查询底部菜单
     * @return
     */
    public List<FootMenu> list();

    /**
     * 获取总记录数
     * @return
     */
    public Long getTotal();

    /**
     * 根据id查询实体
     * @param id
     * @return
     */
    public FootMenu findById(Integer id);

    /**
     * 添加底部菜单信息
     * @param footmenu
     * @return
     */
    public Integer add(FootMenu footmenu);

    /**
     * 修改底部菜单信息
     * @param footmenu
     * @return
     */
    public Integer update(FootMenu footmenu);

    /**
     * 删除底部菜单信息
     * @param id
     * @return
     */
    public Integer delete(Integer id);

}
