package com.java1234.controller.admin;

import com.java1234.entity.Menu;
import com.java1234.run.StartupRunner;
import com.java1234.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员-菜单控制器
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value = "/admin/menu")
public class MenuAdminController {

	@Autowired
	private MenuService menuService;

	@Autowired
	private StartupRunner startupRunner;
	


	/**
	 * 根据条件查询菜单
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value = "/list")
	public Map<String,Object> list()throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		List<Menu> menuList=menuService.list();

		resultMap.put("code", 0);

		resultMap.put("data", menuList);
		return resultMap;
	}
	
	/**
	 * 添加或者修改菜单
	 * @param menu
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/save")
	public Map<String,Object> save(Menu menu){
		if(menu.getId()==null){
			menuService.add(menu);
		}else{
			menuService.update(menu);
		}
		startupRunner.loadData();
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("success", true);
		return resultMap;
	}
	
	/**
	 * 删除菜单
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/delete")
	public Map<String,Object> delete(Integer id)throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		menuService.delete(id);
		startupRunner.loadData();
		resultMap.put("success", true);
		return resultMap;
	}
	
	/**
	 * 根据id查询菜单实体
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/findById")
	public Map<String,Object> findById(Integer id)throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		Menu menu=menuService.findById(id);
		resultMap.put("menu", menu);
		resultMap.put("success", true);
		return resultMap;
	}
}
