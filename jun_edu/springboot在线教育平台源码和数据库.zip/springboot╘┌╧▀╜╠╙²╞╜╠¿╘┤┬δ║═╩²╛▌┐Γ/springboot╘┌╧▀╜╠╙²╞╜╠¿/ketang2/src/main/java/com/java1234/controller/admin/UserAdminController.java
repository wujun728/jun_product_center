package com.java1234.controller.admin;

import com.java1234.constant.Constant;
import com.java1234.entity.User;
import com.java1234.entity.PageBean;
import com.java1234.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员-用户控制器
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-03-19 20:03
 */
@Controller
@RequestMapping(value = "/admin/user")
public class UserAdminController {

    @Autowired
    private UserService userService;


    /**
     * 根据条件分页查询用户
     * @param page
     * @param limit
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/list")
    public Map<String,Object> list(@RequestParam(value="page",required=false)Integer page, @RequestParam(value="limit",required=false)Integer limit, @RequestParam(value="openid",required=false)String openid)throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        PageBean pageBean=new PageBean(page,limit);
        Map<String,Object> map=new HashMap<>();
        map.put("openid",openid);
        map.put("start",pageBean.getStart());
        map.put("size",pageBean.getPageSize());
        List<User> userList=userService.list(map);
        Long count=userService.getTotal(map);
        resultMap.put("code", 0);
        resultMap.put("count", count);
        resultMap.put("data", userList);
        return resultMap;
    }

    /**
     * 修改会员等级
     * @param openid
     * @param vip
     * @param request
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/updateVipState")
    public Map<String,Object> updateVipState(String openid,boolean vip, HttpServletRequest request)throws Exception{
        System.out.println("openid:"+openid);
        System.out.println("vipState:"+vip);
        User user = userService.findById(openid);
        if(vip){
            user.setLevel(Constant.LEVEL_VIP);
        }else{
            user.setLevel(Constant.LEVEL_COMMON);
        }
        userService.update(user);
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", true);
        return resultMap;
    }

}
