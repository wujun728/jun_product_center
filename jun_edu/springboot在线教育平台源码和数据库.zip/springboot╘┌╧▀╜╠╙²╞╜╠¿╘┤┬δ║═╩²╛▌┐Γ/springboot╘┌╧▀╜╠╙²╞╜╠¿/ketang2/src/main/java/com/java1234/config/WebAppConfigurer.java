package com.java1234.config;

import com.java1234.interceptor.WapInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 拦截配置--调用链
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2019-08-13 下午 12:26
 */
@Configuration
public class WebAppConfigurer implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // String[] patterns = new String[] {"/"};
        registry.addInterceptor(new WapInterceptor())
                .addPathPatterns("/**");
    }

    /**
     * 配置虚拟路径映射
     * @param registry
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {

        //文件磁盘图片url 映射
        //配置server虚拟路径，handler为前台访问的目录，locations为files相对应的本地路径
        /*registry.addResourceHandler("/carouselImages/**").addResourceLocations("file:E:\\carouselImages\\");  // 轮转帖子图片映射
        registry.addResourceHandler("/courseImages/**").addResourceLocations("file:E:\\courseImages\\");  // 课程帖子图片映射
        registry.addResourceHandler("/teacherImages/**").addResourceLocations("file:E:\\teacherImages\\");  //  讲师图片映射
        registry.addResourceHandler("/systemImages/**").addResourceLocations("file:E:\\systemImages\\");  // 系统图片映射
        registry.addResourceHandler("/articleImages/**").addResourceLocations("file:E:\\articleImages\\");  // 自定义帖子图片*/
        // registry.addResourceHandler("/image/**").addResourceLocations("file:/home/userImages/");
        registry.addResourceHandler("/carouselImages/**").addResourceLocations("file:/home/carouselImages/");
        registry.addResourceHandler("/courseImages/**").addResourceLocations("file:/home/courseImages/");
        registry.addResourceHandler("/teacherImages/**").addResourceLocations("file:/home/teacherImages/");
        registry.addResourceHandler("/systemImages/**").addResourceLocations("file:/home/systemImages/");
        registry.addResourceHandler("/articleImages/**").addResourceLocations("file:/home/articleImages/");
    }

}
