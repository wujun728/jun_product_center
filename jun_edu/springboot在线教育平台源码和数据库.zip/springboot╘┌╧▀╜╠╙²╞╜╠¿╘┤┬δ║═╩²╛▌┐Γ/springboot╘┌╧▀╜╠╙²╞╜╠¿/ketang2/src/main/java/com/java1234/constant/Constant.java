package com.java1234.constant;

/**
 * 系统所用到的常量
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2019-02-25 下午 10:01
 */
public class Constant {

    /**
     * 自定义加密措施
     */
    public static final String PWD_MD5 = "Cao#@Feng";

    public static final String LEVEL_COMMON="普通会员";

    public static final String LEVEL_VIP="VIP会员";
}
