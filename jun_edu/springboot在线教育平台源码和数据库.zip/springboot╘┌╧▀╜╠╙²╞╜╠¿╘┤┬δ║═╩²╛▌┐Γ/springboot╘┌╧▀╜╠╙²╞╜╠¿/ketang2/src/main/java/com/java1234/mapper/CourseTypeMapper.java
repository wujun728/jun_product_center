package com.java1234.mapper;

import com.java1234.entity.CourseType;

import java.util.List;


/**
 * 课程类别Mapper接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:41
 */
public interface CourseTypeMapper {

    /**
     * 根据id查询课程类别
     * @param id
     * @return
     */
    public CourseType findById(Integer id);


    /**
     * 查询所有课程类别
     * @return
     */
    public List<CourseType> list();

    /**
     * 添加课程类别
     * @param courseType
     * @return
     */
    public Integer add(CourseType courseType);

    /**
     * 修改课程类别
     * @param courseType
     * @return
     */
    public Integer update(CourseType courseType);

    /**
     * 删除课程类别
     * @param id
     * @return
     */
    public Integer delete(Integer id);


}
