package com.java1234.service.impl;

import com.java1234.entity.Teacher;
import com.java1234.mapper.TeacherMapper;
import com.java1234.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 授课老师Service实现类
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:34
 */
@Service("teacherService")
public class TeacherServiceImpl implements TeacherService {

    @Autowired
    private TeacherMapper teacherMapper;

    @Override
    public List<Teacher> list() {
        return teacherMapper.list();
    }

    @Override
    public Teacher findById(Integer id) {
        return teacherMapper.findById(id);
    }

    @Override
    public Integer add(Teacher teacher) {
        return teacherMapper.add(teacher);
    }

    @Override
    public Integer update(Teacher teacher) {
        return teacherMapper.update(teacher);
    }

    @Override
    public Integer delete(Integer id) {
        return teacherMapper.delete(id);
    }
}
