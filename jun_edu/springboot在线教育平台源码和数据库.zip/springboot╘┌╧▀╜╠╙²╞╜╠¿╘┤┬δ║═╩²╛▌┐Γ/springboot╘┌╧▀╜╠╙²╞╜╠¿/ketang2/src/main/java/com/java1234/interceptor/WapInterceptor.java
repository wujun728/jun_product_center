package com.java1234.interceptor;


import com.java1234.util.DeviceUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * wap拦截器，对指定请求 转发到wap移动端页面，提高用户浏览体验
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-06-23 11:41
 */
public class WapInterceptor implements HandlerInterceptor {

    private final static Logger logger= LoggerFactory.getLogger(WapInterceptor.class);
    
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String contextPath = request.getRequestURI();
        System.out.println("路径"+contextPath);
        String userAgent=request.getHeader("user-agent");
        if(DeviceUtil.isMobileDevice(userAgent)) { // 移动设备 需要进行跳转
            if("/".equals(contextPath)){ // 如果是根路径 /
                request.getRequestDispatcher("/wapIndex").forward(request,response);
                return false;
            }
            if(contextPath.startsWith("/course/")){ // 如果是课程请求
                request.getRequestDispatcher("/wap"+contextPath).forward(request,response);
                return false;
            }
            if(contextPath.startsWith("/article/")){ // 如果是自定义帖子请求
                request.getRequestDispatcher("/wap"+contextPath).forward(request,response);
                return false;
            }
            if(contextPath.startsWith("/toPayVip")){ // 跳转
                request.getRequestDispatcher("/wap"+contextPath).forward(request,response);
                return false;
            }
        }

        return true;
    }
}
