package com.java1234.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * 首页或者跳转url跳转控制器
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-01-28 下午 11:32
 */
@Controller
public class IndexController {

    private final static Logger logger= LoggerFactory.getLogger(IndexController.class);

    /**
     * 网站根目录请求
     * @return
     */
    @RequestMapping("/")
    public ModelAndView root(){
        ModelAndView mav=new ModelAndView();
        mav.setViewName("index");
        return mav;
    }

    /**
     * 网站根目录请求
     * @return
     */
    @RequestMapping("/wapIndex")
    public ModelAndView wapRoot(){
        ModelAndView mav=new ModelAndView();
        mav.setViewName("wapIndex");
        return mav;
    }


    /**
     * 登录请求
     * @return
     */
    @RequestMapping("/login")
    public String login(){
        return "login";
    }

    /**
     * 进入个人中心
     * @return
     */
    @RequestMapping("/myCenter")
    public String myCenter(){
        return "myCenter";
    }

    /**
     * 进入后台管理请求
     * @return
     */
    @RequestMapping("/admin")
    public String toAdmin(){
        return "admin/main";
    }

    /**
     * 进入vip支付页面
     * @return
     */
    @RequestMapping("/toPayVip")
    public String toPayVip(){
        return "payVip";
    }

    /**
     * 进入vip支付页面-移动端
     * @return
     */
    @RequestMapping("/wap/toPayVip")
    public String toWapPayVip(){
        return "redirect:/article/2";
    }



}
