package com.java1234.service;

import com.java1234.entity.Article;

import java.util.List;
import java.util.Map;

/**
 * 自定义帖子Service接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-03-19 19:30
 */
public interface ArticleService {

    /**
     * 查询自定义帖子
     * @return
     */
    public List<Article> list(Map<String, Object> map);

    /**
     * 获取总记录数
     * @param map
     * @return
     */
    public Long getTotal(Map<String, Object> map);

    /**
     * 根据id查询实体
     * @param id
     * @return
     */
    public Article findById(Integer id);

    /**
     * 添加自定义帖子信息
     * @param article
     * @return
     */
    public Integer add(Article article);

    /**
     * 修改自定义帖子信息
     * @param article
     * @return
     */
    public Integer update(Article article);

    /**
     * 删除自定义帖子信息
     * @param id
     * @return
     */
    public Integer delete(Integer id);
}
