package com.java1234.controller;

import com.java1234.entity.Course;
import com.java1234.entity.PageBean;
import com.java1234.service.CourseService;
import com.java1234.util.PageUtil;
import com.java1234.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 课程控制器
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-06 下午 10:26
 */
@Controller
@RequestMapping("/course")
public class CourseController {

    @Autowired
    private CourseService courseService;



    /**
     * 根据id查询帖子详细信息
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping("/{id}")
    public ModelAndView view(@PathVariable("id")Integer id)throws Exception{
        ModelAndView mav=new ModelAndView();
        Course course = courseService.findById(id);
        mav.setViewName("course");
        mav.addObject("course",course);
        mav.addObject("recommendList",courseService.listRecommend());
        mav.addObject("modelName",course.getName());
        mav.addObject("title",course.getName());
        return mav;
    }

    /**
     * 异步更新view加1操作
     * @param id
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/updateView")
    public void updateView(Integer id)throws Exception{
        Course course = courseService.findById(id);
        course.setView(course.getView()+1);
        courseService.update(course);
    }


    /**
     * 跳到课程列表页面
     * @return
     * @throws Exception
     */
    @RequestMapping("/list")
    public ModelAndView toCourseList(HttpServletResponse response)throws Exception{
        ModelAndView mav=new ModelAndView();
        PageBean pageBean=new PageBean(1,20);
        Map<String,Object> map=new HashMap<>();
        map.put("start", pageBean.getStart());
        map.put("size", pageBean.getPageSize());
        List<Course> courseList = courseService.search(map);
        Long total = courseService.getTotal(map);
        mav.addObject("courseList",courseList);
        mav.addObject("title","课程列表");
        mav.addObject("clearSsessionStorage","yes");
        StringBuffer param=new StringBuffer();
        mav.addObject("pageCode", PageUtil.genPagination("/course/list", total, 1, 20,param.toString()));
        mav.setViewName("courseList");

        return mav;
    }

    /**
     * 根据课程类别，课程分类和课程名称分页搜索课程
     * @param s_name 搜索条件 课程名称
     * @param s_typeId  搜索条件 课程分类
     * @param s_type 搜索条件 课程类别
     * @param page 第几页
     * @return
     * @throws Exception
     */
    @RequestMapping("/list/{page}")
    public ModelAndView search(@RequestParam(value="s_name",required=false)String s_name,@RequestParam(value="s_typeId",required=false)Integer s_typeId, @RequestParam(value="s_type",required=false)String s_type, @PathVariable(value="page",required=false) Integer page)throws Exception{
        if(page==null){ // 假如s_page是null，说明是第一页，我们给一个初始值1
            page=1;
        }
        PageBean pageBean=new PageBean(page,20);
        Map<String,Object> map=new HashMap<>();
        if(StringUtil.isNotEmpty(s_name)){
            map.put("name",s_name.trim());
        }
        map.put("typeId",s_typeId);
        map.put("type",s_type);
        map.put("start", pageBean.getStart());
        map.put("size", pageBean.getPageSize());
        Long total = courseService.getTotal(map);
        List<Course> courseList = courseService.search(map);
        ModelAndView mav=new ModelAndView();
        mav.addObject("courseList",courseList);
        mav.addObject("s_name",s_name);
        mav.addObject("s_typeId",s_typeId);
        mav.addObject("title","课程搜索结果第"+page+"页");
        StringBuffer param=new StringBuffer();
        if(StringUtil.isNotEmpty(s_name)){
            param.append("&s_name="+s_name);
        }
        if(s_typeId!=null){
            param.append("&s_typeId="+s_typeId);
        }
        if(s_type!=null){
            param.append("&s_type="+s_type);
        }
        mav.addObject("pageCode", PageUtil.genPagination("/course/list", total, page, 20,param.toString().replaceFirst("&","?")));
        mav.setViewName("courseList");
        return mav;

    }

}
