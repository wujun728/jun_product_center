package com.java1234;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan(value = "com.java1234.mapper")
@SpringBootApplication
public class KetangApplication {

    public static void main(String[] args) {
        SpringApplication.run(KetangApplication.class, args);
    }

}
