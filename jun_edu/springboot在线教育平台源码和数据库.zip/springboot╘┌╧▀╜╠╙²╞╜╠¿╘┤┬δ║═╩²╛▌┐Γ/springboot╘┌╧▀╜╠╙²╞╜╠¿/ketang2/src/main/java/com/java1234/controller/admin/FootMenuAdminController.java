package com.java1234.controller.admin;

import com.java1234.entity.FootMenu;
import com.java1234.run.StartupRunner;
import com.java1234.service.FootMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员-底部菜单控制器
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value = "/admin/footMenu")
public class FootMenuAdminController {

	@Autowired
	private FootMenuService footMenuService;

	@Autowired
	private StartupRunner startupRunner;
	


	/**
	 * 根据条件查询底部菜单
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value = "/list")
	public Map<String,Object> list()throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		List<FootMenu> footMenuList=footMenuService.list();
		Long count=footMenuService.getTotal();
		resultMap.put("code", 0);
		resultMap.put("count", count);
		resultMap.put("data", footMenuList);
		return resultMap;
	}
	
	/**
	 * 添加或者修改底部菜单
	 * @param footMenu
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/save")
	public Map<String,Object> save(FootMenu footMenu){
		if(footMenu.getId()==null){
			footMenuService.add(footMenu);
		}else{
			footMenuService.update(footMenu);
		}
		startupRunner.loadData();
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("success", true);
		return resultMap;
	}
	
	/**
	 * 删除底部菜单
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/delete")
	public Map<String,Object> delete(Integer id)throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		footMenuService.delete(id);
		startupRunner.loadData();
		resultMap.put("success", true);
		return resultMap;
	}
	
	/**
	 * 根据id查询底部菜单实体
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/findById")
	public Map<String,Object> findById(Integer id)throws Exception{
		Map<String, Object> resultMap = new HashMap<>();
		FootMenu footMenu=footMenuService.findById(id);
		resultMap.put("footMenu", footMenu);
		resultMap.put("success", true);
		return resultMap;
	}
}
