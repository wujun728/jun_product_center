package com.java1234.controller.admin;

import com.java1234.entity.Article;
import com.java1234.entity.PageBean;
import com.java1234.run.StartupRunner;
import com.java1234.service.ArticleService;
import com.java1234.util.DateUtil;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员-自定义帖子控制器
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-03-19 20:03
 */
@Controller
@RequestMapping(value = "/admin/article")
public class ArticleAdminController {

    @Autowired
    private ArticleService articleService;

    @Autowired
    private StartupRunner startupRunner;

    @Value("${imageFilePath}")
    private String imageFilePath;

    /**
     * 根据条件分页查询自定义帖子
     * @param page
     * @param limit
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping(value = "/list")
    public Map<String,Object> list(@RequestParam(value="page",required=false)Integer page, @RequestParam(value="limit",required=false)Integer limit)throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        PageBean pageBean=new PageBean(page,limit);
        Map<String,Object> map=new HashMap<>();
        map.put("start",pageBean.getStart());
        map.put("size",pageBean.getPageSize());
        List<Article> articleList=articleService.list(map);
        Long count=articleService.getTotal(map);
        resultMap.put("code", 0);
        resultMap.put("count", count);
        resultMap.put("data", articleList);
        return resultMap;
    }

    /**
     * 添加或者修改自定义帖子
     * @param article
     * @return
     */
    @ResponseBody
    @RequestMapping("/save")
    public Map<String,Object> save(Article article){
        if(article.getId()==null){
            articleService.add(article);
        }else{
            articleService.update(article);
        }
        startupRunner.loadData();
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 删除自定义帖子
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/delete")
    public Map<String,Object> delete(Integer id)throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        articleService.delete(id);
        startupRunner.loadData();
        resultMap.put("success", true);
        return resultMap;
    }

    /**
     * 根据id查询自定义帖子实体
     * @param id
     * @return
     * @throws Exception
     */
    @ResponseBody
    @RequestMapping("/findById")
    public Map<String,Object> findById(Integer id)throws Exception{
        Map<String, Object> resultMap = new HashMap<>();
        Article article=articleService.findById(id);
        resultMap.put("article", article);
        resultMap.put("success", true);
        return resultMap;
    }


    /**
     * 上传图片
     * @param file
     * @return
     */
    @ResponseBody
    @RequestMapping("/ckeditorUpload")
    public String ckeditorUpload(@RequestParam("upload")MultipartFile file, String CKEditorFuncNum)throws Exception{
        // 获取文件名
        String fileName = file.getOriginalFilename();
        // 获取文件的后缀名
        String suffixName = fileName.substring(fileName.lastIndexOf("."));
        String newFileName=DateUtil.getCurrentDateStr()+suffixName;
        FileUtils.copyInputStreamToFile(file.getInputStream(), new File(imageFilePath+newFileName));

        StringBuffer sb=new StringBuffer();
        sb.append("<script type=\"text/javascript\">");
        sb.append("window.parent.CKEDITOR.tools.callFunction("+ CKEditorFuncNum + ",'" +"/articleImages/"+ newFileName + "','')");
        sb.append("</script>");

        return sb.toString();
    }
    
}
