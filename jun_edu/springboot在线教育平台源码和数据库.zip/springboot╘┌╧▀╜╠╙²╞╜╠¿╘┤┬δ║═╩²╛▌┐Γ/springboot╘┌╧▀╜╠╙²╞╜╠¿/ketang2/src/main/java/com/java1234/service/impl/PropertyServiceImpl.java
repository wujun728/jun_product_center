package com.java1234.service.impl;

import com.java1234.entity.Property;
import com.java1234.mapper.PropertyMapper;
import com.java1234.service.PropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 系统属性Service实现类
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-10 下午 12:25
 */
@Service("propertyService")
public class PropertyServiceImpl implements PropertyService {

    @Autowired
    private PropertyMapper propertyMapper;

    @Override
    public List<Property> list() {
        return propertyMapper.list();
    }

    @Override
    public Integer update(Property property) {
        return propertyMapper.update(property);
    }

    @Override
    public Property findById(Integer id) {
        return propertyMapper.findById(id);
    }
}
