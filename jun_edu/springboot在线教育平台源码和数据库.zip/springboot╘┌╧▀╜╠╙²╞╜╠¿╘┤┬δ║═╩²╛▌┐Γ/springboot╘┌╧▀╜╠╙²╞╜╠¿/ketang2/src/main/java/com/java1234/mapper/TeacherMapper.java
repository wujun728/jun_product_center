package com.java1234.mapper;

import com.java1234.entity.Teacher;
import com.java1234.entity.Teacher;

import java.util.List;


/**
 * 讲师Mapper接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:41
 */
public interface TeacherMapper {

    
    /**
     * 查询所有轮播帖子
     * @return
     */
    public List<Teacher> list();

    /**
     * 根据id查询实体
     * @param id
     * @return
     */
    public Teacher findById(Integer id);

    /**
     * 添加轮播帖子
     * @param teacher
     * @return
     */
    public Integer add(Teacher teacher);

    /**
     * 修改轮播帖子
     * @param teacher
     * @return
     */
    public Integer update(Teacher teacher);

    /**
     * 删除轮播帖子
     * @param id
     * @return
     */
    public Integer delete(Integer id);



}
