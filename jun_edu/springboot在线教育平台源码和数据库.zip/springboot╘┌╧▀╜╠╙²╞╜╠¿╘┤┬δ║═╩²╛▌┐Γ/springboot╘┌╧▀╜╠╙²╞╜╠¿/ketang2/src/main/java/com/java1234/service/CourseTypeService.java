package com.java1234.service;

import com.java1234.entity.CourseType;

import java.util.List;

/**
 * 课程类别Service接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-02-03 下午 2:33
 */
public interface CourseTypeService {

    /**
     * 查询所有课程类别
     * @return
     */
    public List<CourseType> list();

    /**
     * 根据id查询实体
     * @param id
     * @return
     */
    public CourseType findById(Integer id);

    /**
     * 添加课程类别信息
     * @param courseType
     * @return
     */
    public Integer add(CourseType courseType);

    /**
     * 修改课程类别信息
     * @param courseType
     * @return
     */
    public Integer update(CourseType courseType);

    /**
     * 删除课程类别信息
     * @param id
     * @return
     */
    public Integer delete(Integer id);


}
