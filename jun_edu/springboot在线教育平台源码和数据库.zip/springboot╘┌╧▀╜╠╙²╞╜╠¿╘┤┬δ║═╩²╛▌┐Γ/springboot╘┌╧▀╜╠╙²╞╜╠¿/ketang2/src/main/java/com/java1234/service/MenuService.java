package com.java1234.service;

import com.java1234.entity.Menu;

import java.util.List;


/**
 * 菜单Service接口
 * @author java1234_小锋
 * @site www.java1234.com
 * @company Java知识分享网
 * @create 2020-04-05 11:46
 */
public interface MenuService {

    /**
     * 查询友情链接
     * @return
     */
    public List<Menu> list();

    /**
     * 获取总记录数
     * @return
     */
    public Long getTotal();

    /**
     * 根据id查询实体
     * @param id
     * @return
     */
    public Menu findById(Integer id);

    /**
     * 添加友情链接信息
     * @param menu
     * @return
     */
    public Integer add(Menu menu);

    /**
     * 修改友情链接信息
     * @param menu
     * @return
     */
    public Integer update(Menu menu);

    /**
     * 删除友情链接信息
     * @param id
     * @return
     */
    public Integer delete(Integer id);

}
