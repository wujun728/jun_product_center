//package com.jun.plugin.system.code;
//
//import java.util.List;
//
///**
// */
//public class AutoConfigModel {
//	/**表名称**/
//	private String tableName;
//	/**表描述**/
//	private String tableComment;
//
//	private List<BeanColumn> beanColumns;
//	public String getTableName() {
//		return tableName;
//	}
//	public void setTableName(String tableName) {
//		this.tableName = tableName;
//	}
//	public String getTableComment() {
//		return tableComment;
//	}
//	public void setTableComment(String tableComment) {
//		this.tableComment = tableComment;
//	}
//
//	public AutoConfigModel() {
//		super();
//	}
//	public List<BeanColumn> getBeanColumns() {
//		return beanColumns;
//	}
//	public void setBeanColumns(List<BeanColumn> beanColumns) {
//		this.beanColumns = beanColumns;
//	}
//	public AutoConfigModel(String tableName, String tableComment,
//			List<BeanColumn> beanColumns) {
//		super();
//		this.tableName = tableName;
//		this.tableComment = tableComment;
//		this.beanColumns = beanColumns;
//	}
//
//
//}
