package com.jun.plugin.generator.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jun.plugin.generator.code.BeanColumn;
import com.jun.plugin.generator.code.TsysTables;
import com.jun.plugin.generator.entity.SysGenerator;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * 代码生成 Mapper
 *
 * @author wujun
 * @version V1.0
 * @date 2020年3月18日
 */
public interface GeneratorMapper extends BaseMapper<SysGenerator> {

    @Select({"<script>",
            "  SELECT\n" +
            "        TABLE_NAME AS tableName,\n" +
            "        TABLE_COMMENT AS tableComment,\n" +
            "        CREATE_TIME AS createTime\n" +
            "        FROM\n" +
            "        information_schema.TABLES\n" +
            "        WHERE\n" +
            "        TABLE_SCHEMA = ( SELECT DATABASE ( ) )\n" +
            "        <if test=\"vo.tableName != null and vo.tableName != ''\">\n" +
            "            and TABLE_NAME LIKE concat('%',#{vo.tableName},'%')\n" +
            "        </if>\n" +
            "        ORDER BY\n" +
            "        CREATE_TIME DESC "
            , "</script>"})
    IPage<SysGenerator> selectAllTables(Page<SysGenerator> page, @Param(value = "vo") SysGenerator vo);

    @Select({"  select table_name tableName, engine, table_comment tableComment, create_time createTime from information_schema.tables\n" +
            "\t\t\twhere table_schema = (select database()) and table_name = #{tableName}  "})
    Map<String, String> queryTable(String tableName);

    @Select({"<script>",
            "  select column_name columnName, data_type dataType, column_comment columnComment, column_key columnKey, extra \n" +
                    "\t\t,character_maximum_length maxLength,IS_NULLABLE isNull from information_schema.columns\n" +
                    " \t\t\twhere table_name = #{tableName} and table_schema = (select database()) order by ordinal_position  "
            , "</script>"})
    List<Map<String, String>> queryColumns(String tableName);


    /**
     * 查询当前所有表
     * @param tableName 条件搜索
     * @return
     */
    @Select({"<script>",
            "  select table_name , engine, table_comment , create_time  from information_schema.tables\n" +
                    "        where table_schema = (select database())\n" +
                    "        <if test=\"_parameter != null and _parameter.trim() != ''\">\n" +
                    "            and table_name = #{tableName}\n" +
                    "        </if>\n" +
                    "        order by create_time desc  "
            , "</script>"})
    List<TsysTables> queryList(String tableName);

    /**
     * 查询表详情
     * @param tableName
     * @return
     */
    @Select({"<script>",
            "  select\n" +
                    "        TABLE_CATALOG as table_catalog\n" +
                    "        ,TABLE_SCHEMA as table_schema\n" +
                    "        ,TABLE_NAME as table_name\n" +
                    "        ,COLUMN_NAME as column_name\n" +
                    "        ,ORDINAL_POSITION as ordinal_position\n" +
                    "        ,COLUMN_DEFAULT as column_default\n" +
                    "        ,IS_NULLABLE as is_nullable\n" +
                    "        ,DATA_TYPE as data_type\n" +
                    "        ,CHARACTER_MAXIMUM_LENGTH as character_maximum_length\n" +
                    "        <!-- #,CHARACTER_OCTET_LENGTH as character_octet_length\n" +
                    "        #,NUMERIC_PRECISION as numeric_precision\n" +
                    "        #,NUMERIC_SCALE as numeric_scale\n" +
                    "        #,DATETIME_PRECISION as datetime_precision\n" +
                    "        #,CHARACTER_SET_NAME as character_set_name\n" +
                    "        #,COLLATION_NAME as collation_name -->\n" +
                    "        ,COLUMN_TYPE as column_type\n" +
                    "        ,COLUMN_KEY as column_key\n" +
                    "        ,EXTRA as extra\n" +
                    "        <!-- #,PRIVILEGES as privileges -->\n" +
                    "        ,COLUMN_COMMENT as column_comment\n" +
                    "        <!-- ,GENERATION_EXPRESSION as generation_expression -->\n" +
                    "        from information_schema.columns\n" +
                    "        where table_name = #{tableName} and table_schema = (select database()) order by ordinal_position  "
            , "</script>"})
    List<BeanColumn> queryColumns2(String tableName);
    @Select({"<script>",
            "  select\n" +
                    "        TABLE_CATALOG as table_catalog\n" +
                    "        ,TABLE_SCHEMA as table_schema\n" +
                    "        ,TABLE_NAME as table_name\n" +
                    "        ,COLUMN_NAME as column_name\n" +
                    "        ,ORDINAL_POSITION as ordinal_position\n" +
                    "        ,COLUMN_DEFAULT as column_default\n" +
                    "        ,IS_NULLABLE as is_nullable\n" +
                    "        ,DATA_TYPE as data_type\n" +
                    "        ,CHARACTER_MAXIMUM_LENGTH as character_maximum_length\n" +
                    "        <!-- #,CHARACTER_OCTET_LENGTH as character_octet_length\n" +
                    "        #,NUMERIC_PRECISION as numeric_precision\n" +
                    "        #,NUMERIC_SCALE as numeric_scale\n" +
                    "        #,DATETIME_PRECISION as datetime_precision\n" +
                    "        #,CHARACTER_SET_NAME as character_set_name\n" +
                    "        #,COLLATION_NAME as collation_name -->\n" +
                    "        ,COLUMN_TYPE as column_type\n" +
                    "        ,COLUMN_KEY as column_key\n" +
                    "        ,EXTRA as extra\n" +
                    "        <!-- #,PRIVILEGES as privileges -->\n" +
                    "        ,COLUMN_COMMENT as column_comment\n" +
                    "        <!-- ,GENERATION_EXPRESSION as generation_expression -->\n" +
                    "        from information_schema.columns\n" +
                    "        where table_name = #{tableName} and table_schema = (select database()) order by ordinal_position  "
            , "</script>"})
    List<Map<String, String>> queryColumns3(String tableName);
}
