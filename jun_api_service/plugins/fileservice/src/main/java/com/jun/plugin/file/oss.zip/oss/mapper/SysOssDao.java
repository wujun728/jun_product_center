package com.jun.plugin.module.oss.mapper;


import org.apache.ibatis.annotations.Mapper;

import com.jun.plugin.module.oss.common.BaseDao;
import com.jun.plugin.module.oss.entity.SysOssEntity;

/**
 * 类SysOssDao的功能描述:
 * 文件上传
 * @auther hxy
 * @date 2017-08-25 16:14:38
 */
@Mapper
public interface SysOssDao extends BaseDao<SysOssEntity> {
	
}
