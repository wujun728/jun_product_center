package com.jun.plugin.module.oss.common;

/**
 * 类QcloudGroup的功能描述:
 * 腾讯云
 * @auther hxy
 * @date 2017-08-25 16:15:44
 */
public interface QcloudGroup {
}
