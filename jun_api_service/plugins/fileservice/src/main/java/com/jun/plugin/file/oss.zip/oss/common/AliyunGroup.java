package com.jun.plugin.module.oss.common;

/**
 * 类AliyunGroup的功能描述:
 * 阿里云
 * @auther hxy
 * @date 2017-08-25 16:16:07
 */
public interface AliyunGroup {
}
