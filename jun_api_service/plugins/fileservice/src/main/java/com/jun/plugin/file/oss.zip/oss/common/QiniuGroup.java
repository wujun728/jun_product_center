package com.jun.plugin.module.oss.common;

/**
 * 类QiniuGroup的功能描述:
 * 七牛
 * @auther hxy
 * @date 2017-08-25 16:16:13
 */
public interface QiniuGroup {
}
