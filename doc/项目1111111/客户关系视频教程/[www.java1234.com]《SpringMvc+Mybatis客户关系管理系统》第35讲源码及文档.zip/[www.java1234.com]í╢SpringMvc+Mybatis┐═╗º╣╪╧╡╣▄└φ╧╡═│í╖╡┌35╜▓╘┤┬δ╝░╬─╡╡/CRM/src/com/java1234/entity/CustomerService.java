package com.java1234.entity;

import java.util.Date;

/**
 * �ͻ�����ʵ��
 * @author Administrator
 *
 */
public class CustomerService {

	private Integer id; // ���
	private String serveType; // �������� 1,��ѯ 2������ 3��Ͷ��
	private String overview; // ��Ҫ
	private String customer; // �ͻ�
	private String state; // 1���´��� 2���ѷ��� 3���Ѵ��� 4���ѹ鵵
	private String servicerequest; // ��������
	private String createPeople; // ������
	private Date createTime; // ��������
	private String assigner; // ������
	private Date assignTime; // ��������
	private String serviceProce; // ������
	private String serviceProcePeople; // ��������
	private Date serviceProceTime; // ����������
	private String serviceProceResult; // ���������
	private String myd; // �ͻ������
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getServeType() {
		return serveType;
	}
	public void setServeType(String serveType) {
		this.serveType = serveType;
	}
	public String getOverview() {
		return overview;
	}
	public void setOverview(String overview) {
		this.overview = overview;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getServicerequest() {
		return servicerequest;
	}
	public void setServicerequest(String servicerequest) {
		this.servicerequest = servicerequest;
	}
	public String getCreatePeople() {
		return createPeople;
	}
	public void setCreatePeople(String createPeople) {
		this.createPeople = createPeople;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getAssigner() {
		return assigner;
	}
	public void setAssigner(String assigner) {
		this.assigner = assigner;
	}
	public Date getAssignTime() {
		return assignTime;
	}
	public void setAssignTime(Date assignTime) {
		this.assignTime = assignTime;
	}
	public String getServiceProce() {
		return serviceProce;
	}
	public void setServiceProce(String serviceProce) {
		this.serviceProce = serviceProce;
	}
	public String getServiceProcePeople() {
		return serviceProcePeople;
	}
	public void setServiceProcePeople(String serviceProcePeople) {
		this.serviceProcePeople = serviceProcePeople;
	}
	public Date getServiceProceTime() {
		return serviceProceTime;
	}
	public void setServiceProceTime(Date serviceProceTime) {
		this.serviceProceTime = serviceProceTime;
	}
	public String getServiceProceResult() {
		return serviceProceResult;
	}
	public void setServiceProceResult(String serviceProceResult) {
		this.serviceProceResult = serviceProceResult;
	}
	public String getMyd() {
		return myd;
	}
	public void setMyd(String myd) {
		this.myd = myd;
	}
	
	
}
