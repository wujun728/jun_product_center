package com.java1234.entity;

/**
 * �����ֵ�ʵ����
 * @author Administrator
 *
 */
public class DataDic {

	private Integer id; // ���
	private String dataDicName; // �����ֵ�����
	private String dataDicValue; // �����ֵ�ֵ
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDataDicName() {
		return dataDicName;
	}
	public void setDataDicName(String dataDicName) {
		this.dataDicName = dataDicName;
	}
	public String getDataDicValue() {
		return dataDicValue;
	}
	public void setDataDicValue(String dataDicValue) {
		this.dataDicValue = dataDicValue;
	}
	
	
}
