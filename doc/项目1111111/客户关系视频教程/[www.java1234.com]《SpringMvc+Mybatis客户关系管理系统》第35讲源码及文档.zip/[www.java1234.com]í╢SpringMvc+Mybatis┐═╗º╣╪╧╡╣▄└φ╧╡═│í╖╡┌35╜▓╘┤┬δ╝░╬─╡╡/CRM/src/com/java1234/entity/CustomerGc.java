package com.java1234.entity;

/**
 * �ͻ����ɷ���ʵ��
 * @author Administrator
 *
 */
public class CustomerGc {

	private String customerLevel; // �ͻ��ȼ�
	private int customerNum; // �ͻ�����
	
	public String getCustomerLevel() {
		return customerLevel;
	}
	public void setCustomerLevel(String customerLevel) {
		this.customerLevel = customerLevel;
	}
	public int getCustomerNum() {
		return customerNum;
	}
	public void setCustomerNum(int customerNum) {
		this.customerNum = customerNum;
	}
	
	
}
