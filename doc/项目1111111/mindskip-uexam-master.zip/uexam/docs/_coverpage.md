
# 学之思考试系统

> 学之思在线考试系统，支持多种题型：选择题、多选题、判断题、填空题、解答题以及数学公式，包含PC端、小程序端，扩展性强，部署方便、界面设计友好、代码结构清晰。

[Gitee](https://gitee.com/mindskip/uexam)
[Get Started](#quick-start)
