package com.mindskip.xzs.domain.exam;

import lombok.Data;

@Data
public class ExamPaperQuestionItemObject {
    private Integer id;
    private Integer itemOrder;
}
