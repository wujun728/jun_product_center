package com.mindskip.xzs.domain.other;

import lombok.Data;

@Data
public class KeyValue {

    private String name;
    private Integer value;

}
