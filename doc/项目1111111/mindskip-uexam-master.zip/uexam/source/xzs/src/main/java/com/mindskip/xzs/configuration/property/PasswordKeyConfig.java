package com.mindskip.xzs.configuration.property;

import lombok.Data;

@Data
public class PasswordKeyConfig {
    private String publicKey;
    private String privateKey;
}
