package com.mindskip.xzs.base;


/**
 * @author alvis
 */
public abstract class BaseEntity {

}
