package com.mindskip.xzs.base;

import lombok.Data;

/**
 * @author alvis
 */

@Data
public class BasePage {
    private Integer pageIndex;

    private Integer pageSize;

}
