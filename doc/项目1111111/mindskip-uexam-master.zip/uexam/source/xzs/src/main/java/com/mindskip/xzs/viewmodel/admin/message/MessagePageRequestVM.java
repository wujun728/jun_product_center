package com.mindskip.xzs.viewmodel.admin.message;

import com.mindskip.xzs.base.BasePage;
import lombok.Data;

@Data
public class MessagePageRequestVM extends BasePage {
    private String sendUserName;
}
