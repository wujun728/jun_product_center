package com.mindskip.xzs.viewmodel.admin.education;

import com.mindskip.xzs.base.BasePage;
import lombok.Data;

@Data
public class SubjectPageRequestVM extends BasePage {
    private Integer id;
    private Integer level;
}
