package blog.open1111.controller;

import java.util.Arrays;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.druid.util.StringUtils;

import blog.open1111.entity.Article;
import blog.open1111.service.ArticleService;
import blog.open1111.util.StringUtil;

/**
 * ����Controller��
 * @author user
 *
 */
@Controller
@RequestMapping("/article")
public class ArticleController {

	@Resource
	private ArticleService articleService;
	
	@RequestMapping("/{id}")
	public ModelAndView details(@PathVariable("id") Integer id,HttpServletRequest request)throws Exception{
		ModelAndView mav=new ModelAndView();
		Article article=articleService.findById(id);
		article.setClickHit(article.getClickHit()+1);
		articleService.update(article); // ���ӵ������+1
		String tags=article.getTags();
		if(StringUtil.isNotEmpty(tags)){
			String arr[]=tags.split(" ");
			mav.addObject("tags", StringUtil.filterWhite(Arrays.asList(arr)));
		}else{
			mav.addObject("tags", tags);
		}
		mav.addObject("article", article);
		mav.addObject("pageTitle",article.getTitle());
		mav.addObject("pageCode", this.getUpAndDownPageCode(articleService.getLastArticle(id), articleService.getNextArticle(id), request.getServletContext().getContextPath()));
		mav.addObject("mainPage", "foreground/article/view.jsp");
		mav.setViewName("mainTemp");
		return mav;
	}
	
	/**
	 * ��ȡ��һƪ����һƪ����
	 * @param lastArticle
	 * @param netArticle
	 * @param projectContext
	 * @return
	 */
	public String getUpAndDownPageCode(Article lastArticle,Article netArticle,String projectContext){
		StringBuffer pageCode=new StringBuffer();
		if(lastArticle==null || lastArticle.getId()==null){
			pageCode.append("<p>��һƪ��û����</p>");
		}else{
			pageCode.append("<p>��һƪ��<a href='"+projectContext+"/article/"+lastArticle.getId()+".html'>"+lastArticle.getTitle()+"</a></p>");
		}
		if(netArticle==null || netArticle.getId()==null){
			pageCode.append("<p>��һƪ��û����</p>");
		}else{
			pageCode.append("<p>��һƪ��<a href='"+projectContext+"/article/"+netArticle.getId()+".html'>"+netArticle.getTitle()+"</a></p>");
		}
		return pageCode.toString();
	}
}
