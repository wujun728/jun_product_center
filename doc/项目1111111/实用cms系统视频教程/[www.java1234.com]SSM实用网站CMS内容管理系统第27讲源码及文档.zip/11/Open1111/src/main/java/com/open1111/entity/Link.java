package com.open1111.entity;

/**
 * ��������ʵ��
 * @author user
 *
 */
public class Link {

	private Integer id; // ���
	private String name; // ��������
	private String url; // ���ӵ�ַ
	private Integer sortNo; // �������
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Integer getSortNo() {
		return sortNo;
	}
	public void setSortNo(Integer sortNo) {
		this.sortNo = sortNo;
	}
	
	
}
