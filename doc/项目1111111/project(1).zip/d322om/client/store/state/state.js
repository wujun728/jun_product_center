export default {
  count: 0,
  firstName: 'Jokcy',
  lastName: 'Lou',
  todos: [],
  user: null,
  loading: false
}
