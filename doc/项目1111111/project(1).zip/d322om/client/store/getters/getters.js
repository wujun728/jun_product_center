export default {
  fullName (state) {
    return `${state.firstName} 123 ${state.lastName}`
  }
}
