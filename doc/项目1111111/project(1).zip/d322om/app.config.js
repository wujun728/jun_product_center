module.exports = {
  db: {
    appId: 'A6063806368698',
    appKey: '193E1039-3882-CA44-ADB7-E4D08C590A1E'
  },
  cdn: {
    host: 'http://p4t4vcu10.bkt.clouddn.com/',
    bucket: 'vue-study',
    ak: 'GYgaJ3VBYjcfXqA32hZd2r9rrRvAaP_9jfEPhE5n',
    sk: 'X2ZMFccy_viLkHXBFB7TlDyP0QmuCIBQzTJZC6iJ'
  }
}
