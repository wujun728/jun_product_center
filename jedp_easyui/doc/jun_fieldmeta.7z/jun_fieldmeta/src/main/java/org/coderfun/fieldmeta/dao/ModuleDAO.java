package org.coderfun.fieldmeta.dao;

import org.coderfun.fieldmeta.entity.Module;

import klg.j2ee.common.dataaccess.BaseRepository;

public interface ModuleDAO extends BaseRepository<Module, Long> {

}
