package org.coderfun.fieldmeta.service;

import org.coderfun.fieldmeta.entity.Validation;

import klg.j2ee.common.dataaccess.BaseService;

public interface ValidationService extends BaseService<Validation, Long>{

}
