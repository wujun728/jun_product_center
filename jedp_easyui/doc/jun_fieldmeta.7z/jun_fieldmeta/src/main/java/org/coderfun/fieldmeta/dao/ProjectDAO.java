package org.coderfun.fieldmeta.dao;

import org.coderfun.fieldmeta.entity.Project;

import klg.j2ee.common.dataaccess.BaseRepository;

public interface ProjectDAO extends BaseRepository<Project, Long> {

}
