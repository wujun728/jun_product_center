package org.coderfun.sys.dict.dao;

import org.coderfun.sys.dict.entity.CodeItem;

import klg.j2ee.common.dataaccess.BaseRepository;

public interface CodeItemDAO extends BaseRepository<CodeItem, Long> {

}
