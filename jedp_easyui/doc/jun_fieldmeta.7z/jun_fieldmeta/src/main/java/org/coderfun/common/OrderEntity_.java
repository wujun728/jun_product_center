package org.coderfun.common;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-06-12T18:50:43.491+0800")
@StaticMetamodel(OrderEntity.class)
public class OrderEntity_ extends BaseEntity_ {
	public static volatile SingularAttribute<OrderEntity, Double> orderNum;
}
