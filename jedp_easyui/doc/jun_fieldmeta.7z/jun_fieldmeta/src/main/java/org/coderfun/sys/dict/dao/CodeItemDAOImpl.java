package org.coderfun.sys.dict.dao;

public class CodeItemDAOImpl {

}