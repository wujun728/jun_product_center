package org.coderfun.sys.dict.service;

import org.coderfun.sys.dict.entity.CodeClass;

import klg.j2ee.common.dataaccess.BaseService;

public interface CodeClassService extends BaseService<CodeClass, Long>{

}
