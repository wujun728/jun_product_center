package org.coderfun.fieldmeta.dao;

import org.coderfun.fieldmeta.entity.PageField;

import klg.j2ee.common.dataaccess.BaseRepository;

public interface PageFieldDAO extends BaseRepository<PageField, Long> {

}
