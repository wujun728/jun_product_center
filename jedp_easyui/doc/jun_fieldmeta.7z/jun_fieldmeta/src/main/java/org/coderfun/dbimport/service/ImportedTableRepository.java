package org.coderfun.dbimport.service;

import org.coderfun.fieldmeta.entity.ImportedTable;

import klg.j2ee.common.dataaccess.BaseRepository;

public interface ImportedTableRepository extends BaseRepository<ImportedTable, Long> {

}
