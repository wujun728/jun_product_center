package org.coderfun.sys.dict.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import org.coderfun.common.OrderEntity_;

@Generated(value="Dali", date="2019-08-14T11:51:16.266+0800")
@StaticMetamodel(CodeItem.class)
public class CodeItem_ extends OrderEntity_ {
	public static volatile SingularAttribute<CodeItem, String> classCode;
	public static volatile SingularAttribute<CodeItem, String> code;
	public static volatile SingularAttribute<CodeItem, String> name;
	public static volatile SingularAttribute<CodeItem, String> value;
	public static volatile SingularAttribute<CodeItem, String> extension;
	public static volatile SingularAttribute<CodeItem, String> pinyin;
}
