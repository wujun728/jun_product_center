package org.coderfun.fieldmeta.dao;

import org.coderfun.fieldmeta.entity.TypeMapping;

import klg.j2ee.common.dataaccess.BaseRepository;

public interface TypeMappingDAO extends BaseRepository<TypeMapping, Long> {

}
