package org.coderfun.dbimport.service;


import org.coderfun.fieldmeta.entity.ImportedTable;
import org.springframework.stereotype.Service;

import klg.j2ee.common.dataaccess.BaseServiceImpl;

@Service
public class ImportedTableServiceImpl extends BaseServiceImpl<ImportedTable, Long> implements ImportedTableService{

}
