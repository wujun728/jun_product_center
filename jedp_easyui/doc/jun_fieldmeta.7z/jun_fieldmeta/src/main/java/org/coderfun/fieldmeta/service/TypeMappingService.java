package org.coderfun.fieldmeta.service;

import org.coderfun.fieldmeta.entity.TypeMapping;

import klg.j2ee.common.dataaccess.BaseService;

public interface TypeMappingService extends BaseService<TypeMapping, Long>{

}
