package org.coderfun.fieldmeta.dao;

import org.coderfun.fieldmeta.entity.Validation;

import klg.j2ee.common.dataaccess.BaseRepository;

public interface ValidationDAO extends BaseRepository<Validation, Long> {

}
