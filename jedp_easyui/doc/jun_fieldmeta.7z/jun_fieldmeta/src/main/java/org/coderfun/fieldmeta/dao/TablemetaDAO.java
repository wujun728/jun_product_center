package org.coderfun.fieldmeta.dao;

import org.coderfun.fieldmeta.entity.Tablemeta;

import klg.j2ee.common.dataaccess.BaseRepository;

public interface TablemetaDAO extends BaseRepository<Tablemeta, Long> {

}
