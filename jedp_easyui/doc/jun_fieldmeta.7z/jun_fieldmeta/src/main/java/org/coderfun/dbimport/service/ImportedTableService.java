package org.coderfun.dbimport.service;



import org.coderfun.fieldmeta.entity.ImportedTable;

import klg.j2ee.common.dataaccess.BaseService;

public interface ImportedTableService extends BaseService<ImportedTable, Long> {

}
