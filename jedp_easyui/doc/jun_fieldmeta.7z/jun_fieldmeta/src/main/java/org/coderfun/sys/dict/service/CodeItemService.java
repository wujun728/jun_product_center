package org.coderfun.sys.dict.service;

import org.coderfun.sys.dict.entity.CodeItem;

import klg.j2ee.common.dataaccess.BaseService;

public interface CodeItemService extends BaseService<CodeItem, Long>{

}
