package org.coderfun.sys.dict.dao;

import org.coderfun.sys.dict.entity.CodeClass;

import klg.j2ee.common.dataaccess.BaseRepository;

public interface CodeClassDAO extends BaseRepository<CodeClass, Long> {

}
