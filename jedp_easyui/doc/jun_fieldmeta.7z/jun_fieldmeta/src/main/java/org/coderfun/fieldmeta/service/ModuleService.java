package org.coderfun.fieldmeta.service;

import org.coderfun.fieldmeta.entity.Module;

import klg.j2ee.common.dataaccess.BaseService;

public interface ModuleService extends BaseService<Module, Long>{

}
