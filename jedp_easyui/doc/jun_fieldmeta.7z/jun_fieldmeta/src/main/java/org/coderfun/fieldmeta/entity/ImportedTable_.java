package org.coderfun.fieldmeta.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2019-08-23T21:48:01.025+0800")
@StaticMetamodel(ImportedTable.class)
public class ImportedTable_ {
	public static volatile SingularAttribute<ImportedTable, Long> id;
	public static volatile SingularAttribute<ImportedTable, Long> projectId;
	public static volatile SingularAttribute<ImportedTable, String> databaseName;
	public static volatile SingularAttribute<ImportedTable, String> tableName;
}
