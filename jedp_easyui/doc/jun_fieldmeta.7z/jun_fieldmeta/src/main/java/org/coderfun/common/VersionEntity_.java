package org.coderfun.common;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-05-24T12:38:50.084+0800")
@StaticMetamodel(VersionEntity.class)
public class VersionEntity_ extends BaseEntity_ {
	public static volatile SingularAttribute<VersionEntity, Long> version;
}
