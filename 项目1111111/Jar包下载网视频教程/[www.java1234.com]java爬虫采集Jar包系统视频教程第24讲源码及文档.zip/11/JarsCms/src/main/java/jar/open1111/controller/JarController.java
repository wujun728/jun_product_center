package jar.open1111.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import jar.open1111.entity.Jar;
import jar.open1111.lucene.JarsIndex;
import jar.open1111.service.JarService;
import jar.open1111.service.TagService;
import jar.open1111.util.PageUtil;
import jar.open1111.util.StringUtil;

/**
 * Jar��Controller��
 * @author user
 *
 */
@Controller
@RequestMapping("/jar")
public class JarController {

	@Resource
	private TagService tagService;
	
	@Resource
	private JarService jarService;
	
	private JarsIndex jarsIndex=new JarsIndex();
	
	/**
	 * ���ݹؼ��ֲ�ѯ���Jar����Ϣ
	 * @param q
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/q")
	public ModelAndView search(@RequestParam(value="q",required=false)String q,@RequestParam(value="page",required=false)String page,HttpServletRequest request)throws Exception{
		if(StringUtil.isEmpty(page)){
			page="1";
		}
		ModelAndView mav=new ModelAndView();
		List<Jar> jarList=jarsIndex.searchJar(q.trim(), 200);
		mav.addObject("q", q);
		Integer toIndex=jarList.size()>=Integer.parseInt(page)*20?Integer.parseInt(page)*20:jarList.size();
		mav.addObject("jarList", jarList.subList((Integer.parseInt(page)-1)*20, toIndex));
		mav.addObject("resultTotal", jarList.size());
		mav.addObject("tagList", tagService.randomList(200));
		mav.addObject("pageCode", PageUtil.genPagination(request.getServletContext().getContextPath()+"/jar/q.do", jarList.size(), Integer.parseInt(page), 20, "q="+q));
		mav.setViewName("result");
		return mav;
	}
	
	/**
	 * �������jarҳ�� 
	 * @return
	 */
	@RequestMapping("/{uuid}")
	public ModelAndView view(@PathVariable("uuid") String uuid)throws Exception{
		ModelAndView mav=new ModelAndView();
		Jar jar=jarService.findById(uuid);
		jar.setClick(jar.getClick()+1);
		jarService.update(jar);
		mav.addObject("jar", jar);
		mav.addObject("tagList", tagService.randomList(200));
		mav.addObject("relJarList", jarsIndex.searchJar(jar.getName().replaceAll("-", " "), 16));
		mav.setViewName("view");
		return mav;
	}
	
	/**
	 * ����ָ��Jar��
	 * @param uuid
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/download/{uuid}")
	public String download(@PathVariable("uuid") String uuid,HttpServletResponse response)throws Exception{
		Jar jar=jarService.findById(uuid);
		jar.setDownHit(jar.getDownHit()+1);
		jarService.update(jar);
		response.sendRedirect(jar.getPath());
		return null;
	}
	
}
