package jar.open1111.entity;

import java.util.Date;

/**
 * Jarʵ��
 * @author user
 *
 */
public class Jar {

	private String uuid; // ����uuid
	private String name; // jar������
	private String noTagName; // ������ǩ��jar������
	private String path; // ��Դ·��
	private Date updateDate; // ��������
	private String type; // ��Դ���� jar�� sourceԴ�� doc�ı�����
	private Integer click; // �������
	private Integer downHit; // ���ش���
	private Integer indexState; // ����״̬ Ĭ�� 0 0 δ����Lucene���� 1 ����
	private Integer tagState; // tag����״̬ Ĭ��0  0 δ���� 1 ����
	
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNoTagName() {
		return noTagName;
	}
	public void setNoTagName(String noTagName) {
		this.noTagName = noTagName;
	}
	
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getClick() {
		return click;
	}
	public void setClick(Integer click) {
		this.click = click;
	}
	public Integer getDownHit() {
		return downHit;
	}
	public void setDownHit(Integer downHit) {
		this.downHit = downHit;
	}
	public Integer getIndexState() {
		return indexState;
	}
	public void setIndexState(Integer indexState) {
		this.indexState = indexState;
	}
	public Integer getTagState() {
		return tagState;
	}
	public void setTagState(Integer tagState) {
		this.tagState = tagState;
	}
	@Override
	public String toString() {
		return "Jar [uuid=" + uuid + ", name=" + name + ", noTagName=" + noTagName + "]";
	}
	
	
}
