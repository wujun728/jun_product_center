package jar.open1111.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import jar.open1111.dao.JarDao;
import jar.open1111.entity.Jar;
import jar.open1111.service.JarService;

/**
 * Jar Serviceʵ����
 * @author user
 *
 */
@Service("jarService")
public class JarServiceImpl implements JarService{

	@Resource
	private JarDao jarDao;
	
	public Jar findById(String uuid) {
		return jarDao.findById(uuid);
	}

	public Integer update(Jar jar) {
		return jarDao.update(jar);
	}

	public List<Jar> list(Map<String, Object> map) {
		return jarDao.list(map);
	}

	public Long getTotal(Map<String, Object> map) {
		return jarDao.getTotal(map);
	}

	public Integer delete(String uuid) {
		return jarDao.delete(uuid);
	}

	public Integer add(Jar jar) {
		return jarDao.add(jar);
	}

}
