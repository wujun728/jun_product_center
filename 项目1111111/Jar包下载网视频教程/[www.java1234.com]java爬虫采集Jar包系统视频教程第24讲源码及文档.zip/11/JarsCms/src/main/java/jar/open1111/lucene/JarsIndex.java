package jar.open1111.lucene;

import java.io.StringReader;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Fragmenter;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.search.highlight.SimpleSpanFragmenter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import jar.open1111.entity.Jar;
import jar.open1111.util.StringUtil;

/**
 * Jar��������
 * @author user
 *
 */
public class JarsIndex {

	private Directory dir=null;
	
	private static final String LUCENE_PATH="c://lucene5";
	
	/**
	 * ��ȡIndexWriterʵ��
	 * @return
	 * @throws Exception
	 */
	private IndexWriter getWriter()throws Exception{
		dir=FSDirectory.open(Paths.get(LUCENE_PATH));
		Analyzer analyzer=new StandardAnalyzer();
		IndexWriterConfig iwc=new IndexWriterConfig(analyzer);
		IndexWriter writer=new IndexWriter(dir,iwc);
		return writer;
	}
	
	/**
	 * ����jar������
	 * @param jar
	 * @throws Exception
	 */
	public void addIndex(Jar jar)throws Exception{
		IndexWriter writer=getWriter();
		Document doc=new Document();
		doc.add(new StringField("id",jar.getUuid(),Field.Store.YES));
		doc.add(new TextField("name",jar.getName().replaceAll("-", " "),Field.Store.YES));
		writer.addDocument(doc);
		writer.close();
	}
	
	/**
	 * ����jar������
	 * @param jar
	 * @throws Exception
	 */
	public void updateIndex(Jar jar)throws Exception{
		IndexWriter writer=getWriter();
		Document doc=new Document();
		doc.add(new StringField("id",jar.getUuid(),Field.Store.YES));
		doc.add(new TextField("name",jar.getName().replaceAll("-", " "),Field.Store.YES));
		writer.updateDocument(new Term("id",jar.getUuid()), doc);
		writer.close();
	}
	
	/**
	 * ɾ��ָ��jar��������
	 * @param jarId
	 * @throws Exception
	 */
	public void deleteIndex(String jarId)throws Exception{
		IndexWriter writer=getWriter();
		writer.deleteDocuments(new Term("id",jarId));
		writer.forceMergeDeletes(); // ǿ��ɾ��
		writer.commit();
		writer.close();
	}
	
	/**
	 * ��ѯJar����Ϣ
	 * @param q
	 * @param n
	 * @return
	 * @throws Exception
	 */
	public List<Jar> searchJar(String q,int n)throws Exception{
		dir=FSDirectory.open(Paths.get(LUCENE_PATH));
		IndexReader reader=DirectoryReader.open(dir);
		IndexSearcher is=new IndexSearcher(reader);
		
		Analyzer analyzer=new StandardAnalyzer();
		QueryParser parser=new QueryParser("name", analyzer);
		Query query=parser.parse(q);
		
		TopDocs hits=is.search(query, n); // ��ѯn��
		QueryScorer scorer=new QueryScorer(query);
		Fragmenter fragmenter=new SimpleSpanFragmenter(scorer);
		SimpleHTMLFormatter simpleHTMLFormatter=new SimpleHTMLFormatter("<b><font color='red'>", "</font></b>");
		
		Highlighter highlighter=new Highlighter(simpleHTMLFormatter, scorer);
		highlighter.setTextFragmenter(fragmenter);
		List<Jar> jarList=new LinkedList<Jar>();
		for(ScoreDoc scoreDoc:hits.scoreDocs){
			Document doc=is.doc(scoreDoc.doc);
			Jar jar=new Jar();
			jar.setUuid(doc.get("id"));
			String name=doc.get("name");
			jar.setNoTagName(name);
			if(name!=null){
				TokenStream tokenStream=analyzer.tokenStream("name", new StringReader(name));
				String hName=highlighter.getBestFragment(tokenStream, name);
				if(StringUtil.isEmpty(hName)){
					jar.setName(name);
				}else{
					jar.setName(hName);
				}
			}
			jarList.add(jar);
		}
		return jarList;
	}
	
	public static void main(String[] args) throws Exception {
		List<Jar> jarList=new JarsIndex().searchJar("services", 10);
		for(Jar jar:jarList){
			System.out.println(jar);
		}
	}
}
