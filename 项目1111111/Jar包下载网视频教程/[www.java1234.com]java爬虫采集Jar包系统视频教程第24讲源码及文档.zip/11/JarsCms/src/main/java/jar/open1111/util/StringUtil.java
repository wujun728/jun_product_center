package jar.open1111.util;

/**
 * �ַ���������
 * @author user
 *
 */
public class StringUtil {

	/**
	 * �ж��Ƿ��ǿ�
	 * @param hName
	 * @return
	 */
	public static boolean isEmpty(String str) {
		if(str==null || "".equals(str.trim())){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * �ж��Ƿ��ǲ��ǿ�
	 * @param hName
	 * @return
	 */
	public static boolean isNotEmpty(String str) {
		return !isEmpty(str);
	}
	
	
	/**
	 * ��ʽ��ģ����ѯ
	 * @param str
	 * @return
	 */
	public static String formatLike(String str){
		if(isNotEmpty(str)){
			return "%"+str+"%";
		}else{
			return null;
		}
	}

}
