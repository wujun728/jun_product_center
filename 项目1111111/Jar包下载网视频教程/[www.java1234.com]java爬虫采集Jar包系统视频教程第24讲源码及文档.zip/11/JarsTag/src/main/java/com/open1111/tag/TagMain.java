package com.open1111.tag;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.open1111.util.DbUtil;

public class TagMain {

	private static Logger logger=Logger.getLogger(TagMain.class);
	
	public static void main(String[] args) {
		logger.info("����Tag��ʼ");
		DbUtil dbUtil=new DbUtil();
		Connection con=null;
		try {
			con=dbUtil.getCon();
			logger.info("�������ݿ����ӳɹ�");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("�������ݿ�����ʧ��");
		}
		String sql="select * from t_jar where tagState=0";
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				String id=rs.getString("uuid");
				String name=rs.getString("name");
				String names[]=name.replaceAll(".jar", "").split("-");
				for(String n:names){
					if(n.contains(".")){
						continue;
					}
					String sql2="select * from t_tag where name=?";
					PreparedStatement pstmt2=con.prepareStatement(sql2);
					pstmt2.setString(1, n);
					ResultSet rs2=pstmt2.executeQuery();
					if(!rs2.next()){ // ���粻����  ���ǲ���tag
						String sql3="insert into t_tag values(null,?)";
						PreparedStatement pstmt3=con.prepareStatement(sql3);
						pstmt3.setString(1, n);
						pstmt3.executeUpdate();
						logger.info("�����ǩ��"+n);
					}
				}
				// �������ݿ�tagState״̬�ֶ� �ĳ�1
				String sql4="update t_jar set tagState=1 where uuid='"+id+"'";
				PreparedStatement pstmt4=con.prepareStatement(sql4);
				pstmt4.executeUpdate();
			}
		} catch (SQLException e) {
			logger.error("SQLException",e);
		}
		try {
			dbUtil.closeCon(con);
		} catch (Exception e) {
			logger.error("Exception",e);
		}
		logger.info("����Tag����");
	}
}
